﻿using AuthorizationAPI.Models;
using AuthorizationAPI.Provider;
using Microsoft.EntityFrameworkCore;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthTest
{
    class ProviderTest
    {
        List<UserCredentials> users = new List<UserCredentials>();
        Mock<DbSet<UserCredentials>> dbSetMoq;

        [SetUp]
        public void Setup()
        {
            users.Add(new UserCredentials { Id = 1, Username = "admin", Password = "admin", Counter = 2 });

            dbSetMoq = new Mock<DbSet<UserCredentials>>();

            var queriableUserList = users.AsQueryable();

            dbSetMoq.As<IQueryable<UserCredentials>>().Setup(x => x.Provider).Returns(queriableUserList.Provider);
            dbSetMoq.As<IQueryable<UserCredentials>>().Setup(x => x.Expression).Returns(queriableUserList.Expression);
            dbSetMoq.As<IQueryable<UserCredentials>>().Setup(x => x.ElementType).Returns(queriableUserList.ElementType);
            dbSetMoq.As<IQueryable<UserCredentials>>().Setup(x => x.GetEnumerator()).Returns(queriableUserList.GetEnumerator());
        }



        [TestCase]
        public void GetUserTest()
        {
            var moqContext = new Mock<UserCredentialContext>();
            moqContext.Setup(v => v.Users).Returns(dbSetMoq.Object);

            UserProvider provider = new UserProvider(moqContext.Object);

            UserCredentials user = new UserCredentials { Username = "admin", Password = "admin" };

            var result = provider.GetUser(user);

            Assert.IsNotNull(result);
        }

        [TestCase]
        public void RegisterUserTest()
        {
            var moqContext = new Mock<UserCredentialContext>();
            moqContext.Setup(v => v.Users).Returns(dbSetMoq.Object);

            UserProvider provider = new UserProvider(moqContext.Object);

            UserCredentials user = new UserCredentials { Username = "root", Password = "root" };

            var result = provider.RegisterUser(user);

            Assert.IsTrue(result);
        }

        [TestCase]
        public void IncrementCounterTest()
        {
            var moqContext = new Mock<UserCredentialContext>();
            moqContext.Setup(v => v.Users).Returns(dbSetMoq.Object);

            UserProvider provider = new UserProvider(moqContext.Object);

            UserCredentials user = new UserCredentials { Username = "user", Password = "user" };

            var result = provider.IncrementCounter(user);

            Assert.IsNotNull(result);
        }
    }
}
