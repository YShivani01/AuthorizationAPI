﻿using AuthorizationAPI.Controllers;
using AuthorizationAPI.Models;
using AuthorizationAPI.Repository;
using AuthorizationAPI.Service;
using Castle.Core.Configuration;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using System.Text;
using System.Threading.Tasks;
using IConfiguration = Microsoft.Extensions.Configuration.IConfiguration;
using System.IdentityModel.Tokens.Jwt;
using AuthorizationAPI.Context;

namespace AuthAPITest
{
    class ProviderTest

    {
        public Dictionary<string, string> dc = new Dictionary<string, string>()
        {
               {"user1","pass1"},
               {"user2","pass2"},

        };
        List<UserCredentials> user;
        List<UserToken> token;
        private readonly IConfiguration _config;
        Mock<UserContext> userContext;
        [SetUp]
        public void Setup1()
        {
            user = new List<UserCredentials>()
            {
                new UserCredentials{ Id=1, Username="Jin", Password="pass",Address="hyd"},
                new UserCredentials{ Id=2, Username="Jimin", Password="pass",Address="delhi"},
               
                //new UserCredentials{ userid=3,password="1235987",username="Shailesh"}
            };

        }
        [Test]
        public void GetAllUsers_ReturnOkRequest()
        {
            var mock = new Mock<IUserService>();
            mock.Setup(m => m.GetAllUsers()).Returns(user);
            AuthController authController = new AuthController(mock.Object);
            OkObjectResult objectResult = (OkObjectResult)authController.GetAllUsers();
            Assert.AreEqual(200, objectResult.StatusCode);
        }
        [Test]
        public void GetAllUsers_ReturnNotNullList()
        {
        
            var mock = new Mock<IUserService>();
            mock.Setup(m => m.GetAllUsers()).Returns(user);
            AuthController authController = new AuthController(mock.Object);
            var data = authController.GetAllUsers();
            Assert.IsNotNull(data);
        }
        [Test]
        public void ValidateUser_ValidInput_ReturnsOKRequest()
        {
            //int id = 2;
            //string name = "Jimin", Pass = "pass";
            /*var details = new UserToken
            {
                Username = "Jimin", Password = "pass"
            };

             //var mock = new Mock<IUserRepo>();
            var mock = new Mock<IUserRepo>();
            mock.Setup(x => x.GetUser(details)).Returns(user);
            UserService userService = new UserService(Mock.Object);
            AuthController authController=new AuthController()
            {

            }
           // .Returns((token.Where<x => x.Username==details.Username >)).FirstOrDefault());
                //Returns((user.Where<x =>x.Username=details.Username ));     
           }
        [TestCase("user1", "pass1")]
        public void CorrectCredProviderTest(string name, string pass)
        {

            Mock<IUserRepo> mock = new Mock<IUserRepo>();
            mock.Setup(p => p.GetUser()).Returns(user);

            UserRepo cp = new UserRepo(mock.Object);
             user = new Authenticate()
            {
                Name = name,
                Password = pass
            };
            Authenticate result = cp.AuthenticateUser(user);
            Assert.IsNotNull(result);*/
            var details = new UserToken
            {
                Username = "Jimin",
                Password = "pass"
            };
            var mock = new Mock<IUserService>();
            mock.Setup(x => x.GetUser(details)).Returns((user.Where(a => a.Username == details.Username)).FirstOrDefault());
            AuthController authController = new AuthController(mock.Object);
            var data = authController.ValidateUser(details);
            //var res = data as ObjectResult;
            //Assert.AreEqual(200, ObjectResult.StatusCode);

        }

        [Test]
        public void ValidateUser_InvalidInput_ReturnsOKRequest()
        {
            var details = new UserToken
            {
                Username = "suga",
                Password = "admin"
            };
            var mock = new Mock<IUserService>();
            try
            {
                mock.Setup(x => x.GetUser(details)).Returns((user.Where(a => a.Username == details.Username)).FirstOrDefault());
                AuthController authController = new AuthController(mock.Object);
                var data = authController.ValidateUser(details);

            }
            catch(Exception e)
            {
                Assert.AreEqual("User Not Found", e.Message);
            }
            
        }
        [Test]
        public void GetAllUsers_NotNullRequest()
        {
            var details = new UserToken
            {
                Username = "suga",
                Password = "admin"
            };
            var mock = new Mock<IUserService>();
            mock.Setup(x => x.GetUser(details)).Returns((user.Where(a => a.Username == details.Username)).FirstOrDefault());
            AuthController authController = new AuthController(mock.Object);
            //var data = authController.GetAllUsers(details);
            var data = authController.ValidateUser(details);
            Assert.IsNotNull(data);

        }
       [TestCase("user1", "pass1")]
        [TestCase("user2", "pass2")]
         public void TokenGenarationTest(string name, string pass)
         {

             Mock<IConfiguration> config = new Mock<IConfiguration>();
             config.Setup(p => p["Jwt:Key"]).Returns("ThisismySecretKey");
             //Mock<IUserRepo> mock = new Mock<IUserRepo>();
            Mock<IUserService> mock = new Mock<IUserService>();
            mock.Setup(p => p.GetAllUsers()).Returns(user);
            //AuthProvider cp = new AuthProvider(mock.Object);
            AuthController authController = new AuthController(mock.Object);
           // UserService userService = new UserService(mock.Object,_config);
           var details = new UserToken
            {
                Username = "suga",
                Password = "admin"
            };
            //var token = new JwtSecurityToken(_config["Jwt:Issuer"],
            //_config["Jwt:Issuer"],
            //string _token = UserService.GenerateJSONWebToken();
            string result = authController.ValidateUser(details);
             Assert.IsNotNull(result);
         }
        




    }
}
