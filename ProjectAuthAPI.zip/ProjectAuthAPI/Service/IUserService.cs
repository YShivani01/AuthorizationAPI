﻿using ProjectAuthAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAuthAPI.Service
{
   public interface IUserService
    {
        public List<UserCredentials> GetAllUsers();
        public UserCredentials GetUser(User user);
        public string GenerateJSONWebToken(string userRole);
    }
}
