﻿using ProjectAuthAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAuthAPI.AuthRepository
{
  public  interface IAuthRepo
    {
        //public List<UserCredentials> GetAllUsers();
        public List<UserCredentials> GetAllUsers();
       // public Agent GetAgent(User user);
        public UserCredentials GetUser(User user);
    }
}
