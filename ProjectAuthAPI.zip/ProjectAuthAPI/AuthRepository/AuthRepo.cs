﻿using ProjectAuthAPI.Context;
using ProjectAuthAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAuthAPI.AuthRepository
{
    public class AuthRepo : IAuthRepo
    {
        private readonly UserCredentialsContext usercredentialscontext;
        public AuthRepo(UserCredentialsContext _usercredentialscontext)
        {
            usercredentialscontext = _usercredentialscontext;
        }
        public List<UserCredentials> GetAllUsers()
        {
            List<UserCredentials> users = usercredentialscontext.users.ToList();
            return users;
        }

        public UserCredentials GetUser(User user)
        {
            return GetAllUsers().SingleOrDefault(u => u.UserName == user.UserName && u.Password == user.Password);
        }
    }
}
