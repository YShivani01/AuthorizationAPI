﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ProjectAuthAPI.Context;
using ProjectAuthAPI.Models;
using ProjectAuthAPI.Service;

namespace ProjectAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserService userService;
        private readonly log4net.ILog _log4Net;
        private object repo;

        public AuthController(IUserService _userService)
        {
            userService = _userService;
            _log4Net = log4net.LogManager.GetLogger(typeof(AuthController));

        }


        /// Post method for Login


        [HttpPost]
        public string VerifyUser([FromBody] User user)
        {
            var verifyuser = userService.GetUser(user);
            if (verifyuser == null)
            {
                _log4Net.Info("No User is Found");
                return "User Not Found";
            }
            else
            {
                string tokenString = userService.GenerateJSONWebToken("User");
                _log4Net.Info("User is Found");
                _log4Net.Info("Token is Generated");
                return tokenString;
            }
            
            
        }

       // [Route("Register")]
        //[HttpPost]
        /*public IActionResult Register([FromBody] UserCredentials reg)
        {

            _log4Net.Info("Login initiated!");

            if (repo.RegisterUserCred(reg))
                return Ok();
            return NotFound();
        }*/
        [HttpGet("GetAllUsers")]
        public IActionResult GetAllAgents()
        {
            _log4Net.Info("Getting All Users");
            return Ok(userService.GetAllUsers().ToList());
        }
    }
}
