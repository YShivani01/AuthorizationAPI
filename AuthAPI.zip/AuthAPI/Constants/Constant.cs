﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthorizationAPI.Constants
{
    public static class Constant
    {
        public static string UserNotFound => "User is not found";

        public static string UserBanned => "User is Banned";
    }
}
